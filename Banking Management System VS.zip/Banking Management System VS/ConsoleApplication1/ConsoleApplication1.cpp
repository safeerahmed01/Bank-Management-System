#include<iostream>
#include<fstream>
#include<string>
using namespace std;

void adminLogin();
void adminMenu();
void searchAcc();
void openAcc();
void closeAcc();
void userLogin();
void userMenu();
void viewBal();
void transferMoney();
void depositCash();
void withdrawCash();
void changePass();
bool searchID(string);
int endMenu();
int choice = 1;

int main() {
	int menu=0;
	while (choice == 1 && menu != 3) {
		cout << endl << "***** Banking Management System *****" << endl;
		cout << endl << "Greetings! \n\n1. User Login \n2. Admin Login \n3. Exit" << endl;
		cout << endl << "Enter Choice: ";
		cin >> menu;
		cin.ignore();
		cout << endl;
		switch (menu) {
		case 1:
			userLogin();
			break;
		case 2:
			adminLogin();
			break;
		case 3:
			break;
		default:
			cout << endl << "Invalid Input!" << endl;
		}
	}
	if (choice == 2 || menu == 3) {
		cout << "Glad to be of service. Have a nice day!" << endl;
	}
	return 0;
}

void adminLogin() {
	string adminID, adminPass, out;
	bool found = false;

	cout << "Enter Admin ID: ";
	getline(cin, adminID);
	cout << "Enter Admin Password: ";
	getline(cin, adminPass);
	ifstream in("adminAccounts.txt");
	while (getline(in, out)) {
		if (adminID == out) {
			getline(in, out);
			if (adminPass == out) {
				cout << endl << "Login Successful!" << endl;
				found = true;
				in.close();
				adminMenu();
				return;
			}
		}
	}
	if (!found) {
		cout << endl << "Incorrect ID or Password!" << endl;
		in.close();
		endMenu();
		return;
	}
	in.close();
}

void adminMenu() {
	int choice;

	cout << endl << "*** Logged in as an Administrator ***" << endl;
	cout << endl << "1. Search for an Account \n2. Open an Account \n3. Close an Account \n4. Main Menu" << endl;
	cout << endl << "Enter Choice: ";
	cin >> choice;
	cin.ignore();
	switch (choice) {
	case 1:
		searchAcc();
		break;
	case 2:
		openAcc();
		break;
	case 3:
		closeAcc();
		break;
	case 4:
		break;
	default:
		cout << endl << choice << " is not a valid choice! Choose a valid Option." << endl;
		return adminMenu();
		break;
	}
}

void searchAcc() {
	string id, out;
	string acc[] = { "Account Number: ", "Account Holders Name: ", "Account Balance: PKR " };
	bool found = false;

	cout << endl << "Enter the User ID: ";
	cin >> id;
	cin.ignore();

	ifstream in("accounts.txt");
	while (in.eof() == 0) {
		getline(in, out);
		if (id == out) {
			cout << endl << "*** Account Details ***" << endl;
			cout << endl << acc[0] << out << endl;
			found = true;
			getline(in, out);
			for (int i = 0; i < 2; i++) {
				getline(in, out);
				cout << acc[i + 1] << out << endl;
			}
		}
	}
	if (!found) {
		cout << endl << "Account not found! Enter a valid account ID." << endl;
	}
	in.close();

	adminMenu();
	return;
}

void openAcc() {
	string id, pass, name;
	float bal;

	cout << endl << "Enter Account ID: ";
	getline(cin, id);
	if (searchID(id)) {
		cout << endl << "User ID already exists! Enter a unique ID." << endl;
		return adminMenu();
	}
	cout << "Enter Account Password: ";
	getline(cin, pass);
	cout << "Enter Account Holders Name: ";
	getline(cin, name);
	cout << "Enter Starting Account Balance: ";
	cin >> bal;
	cin.ignore();

	ofstream out("accounts.txt", ios::app);
	out << id << endl;
	out << pass << endl;
	out << name << endl;
	out << bal << endl;
	out.close();

	cout << endl << "Account created Successfully!" << endl;

	adminMenu();
	return;
}

void closeAcc() {
	string id, temp;
	bool found = false;

	cout << endl << "Enter Account ID: ";
	getline(cin, id);
	if (!searchID(id)) {
		cout << endl << "User does not exist! Enter a valid ID." << endl;
		return adminMenu();
	}

	ofstream out("temp.txt");
	ifstream in("accounts.txt");
	while (getline(in, temp)) {
		if (temp == id) {
			found = true;
			for (int i = 0; i < 3; i++) {
				getline(in, temp);
			}
		}
		else {
			out << temp << endl;
		}
	}
	in.close();
	out.close();

	if (found) {
		remove("accounts.txt");
		rename("temp.txt", "accounts.txt");
		cout << endl << "Account closed Successfully!" << endl;
	}

	adminMenu();
	return;
}

string userID, userPass;
void userLogin() {
	string out;
	bool found = false;

	cout << "Enter User ID: ";
	getline(cin, userID);
	cout << "Enter User Password: ";
	getline(cin, userPass);

	ifstream in("accounts.txt");
	while (getline(in, out)) {
		if (userID == out) {
			getline(in, out);
			if (userPass == out) {
				cout << endl << "Login Successful!" << endl;
				found = true;
				in.close();
				userMenu();
				return;
			}
		}
	}
	if (!found) {
		cout << endl << "Incorrect ID or Password!" << endl;
		in.close();
		endMenu();
		return;
	}
	in.close();
}

void userMenu() {
	int choice;
	string out;

	ifstream in("accounts.txt");
	while (getline(in, out)) {
		if (out == userID) {
			getline(in, out);
			getline(in, out);
			break;
		}
	}
	in.close();

	cout << endl << "*** Welcome " << out << " ***" << endl;
	cout << endl << "1. View Balance \n2. Transfer Money \n3. Deposit Money \n4. Withdraw Money \n5. Change Password \n6. Main Menu";
	cout << endl << endl << "Enter Choice: ";
	cin >> choice;
	cin.ignore();
	switch (choice) {
	case 1:
		return viewBal();
	case 2:
		return transferMoney();
	case 3:
		return depositCash();
	case 4:
		return withdrawCash();
	case 5:
		return changePass();
	case 6:
		return;
	default:
		cout << endl << choice << " is not a valid choice! Choose a Valid Option." << endl;
		return userMenu();
	}
}

void viewBal() {
	string out;

	ifstream in("accounts.txt");
	while (getline(in, out)) {
		if (out == userID) {
			for (int i = 0; i < 3; i++) {
				getline(in, out);
			}
			cout << endl << "Current Balance: PKR " << out << endl;
		}
	}
	in.close();

	userMenu();
	return;
}

void transferMoney() {
	string temp, id;
	bool found = false;
	float bal;

	cout << endl << "Enter Receivers ID: ";
	getline(cin, id);
	if (!searchID(id)) {
		cout << endl << "Account not found!" << endl;
		return userMenu();
	}

	ofstream out("temp.txt");
	ifstream in("accounts.txt");
	while (getline(in, temp)) {
		if (temp == userID) {
			found = true;
			out << temp << endl;
			for (int i = 0; i < 3; i++) {
				getline(in, temp);
				if (i != 2) {
					out << temp << endl;
				}
				if (i == 2) {
					cout << "Enter Amount: ";
					cin >> bal;
					cin.ignore();
					float oldBal = stof(temp);
					if (bal > oldBal) {
						cout << endl << "Amount exceeds current balance!" << endl;
						out << temp << endl;
						found = false;
					}
					else {
						out << oldBal - bal << endl;
					}
				}
			}
		}
		else {
			out << temp << endl;
		}
	}
	in.close();
	out.close();
	remove("accounts.txt");
	rename("temp.txt", "accounts.txt");

	if (!found) {
		return userMenu();
	}

	ofstream outt("temp.txt");
	ifstream inn("accounts.txt");
	while (getline(inn, temp)) {
		if (temp == id) {
			outt << temp << endl;
			for (int i = 0; i < 3; i++) {
				getline(inn, temp);
				if (i != 2) {
					outt << temp << endl;
				}
				if (i == 2) {
					float tempBal = stof(temp);
					outt << bal + tempBal << endl;
				}
			}
		}
		else {
			outt << temp << endl;
		}
	}
	inn.close();
	outt.close();
	remove("accounts.txt");
	rename("temp.txt", "accounts.txt");

	if (found) {
		cout << endl << "Amount Transfered Successfully!" << endl;
	}
	userMenu();
	return;
}

void depositCash() {
	string temp;
	bool found = false;
	float bal;

	ofstream out("temp.txt");
	ifstream in("accounts.txt");
	while (getline(in, temp)) {
		if (temp == userID) {
			out << temp << endl;
			found = true;
			for (int i = 0; i < 3; i++) {
				getline(in, temp);
				if (i != 2) {
					out << temp << endl;
				}
				if (i == 2) {
					cout << endl << "Enter Amount: ";
					cin >> bal;
					cin.ignore();
					float oldBal = stof(temp);
					out << bal + oldBal << endl;
				}
			}
		}
		else {
			out << temp << endl;
		}
	}
	in.close();
	out.close();

	if (found) {
		remove("accounts.txt");
		rename("temp.txt", "accounts.txt");
		cout << endl << "Cash Deposited Successfully!" << endl;
	}

	userMenu();
	return;
}

void withdrawCash() {
	string temp;
	bool found = false;
	float bal;

	ofstream out("temp.txt");
	ifstream in("accounts.txt");
	while (getline(in, temp)) {
		if (temp == userID) {
			out << temp << endl;
			found = true;
			for (int i = 0; i < 3; i++) {
				getline(in, temp);
				if (i != 2) {
					out << temp << endl;
				}
				if (i == 2) {
					cout << endl << "Enter Amount: ";
					cin >> bal;
					cin.ignore();
					float oldBal = stof(temp);
					if (bal > oldBal) {
						cout << endl << "Amount exceeds current balance!" << endl;
						out << temp << endl;
						found = false;
					}
					else {
						out << oldBal - bal << endl;
					}
				}
			}
		}
		else {
			out << temp << endl;
		}
	}
	in.close();
	out.close();
	remove("accounts.txt");
	rename("temp.txt", "accounts.txt");

	if (found) {
		cout << endl << "Cash Withdrawl Successful!" << endl;
	}

	userMenu();
	return;
}

void changePass() {
	string temp, pass;

	ofstream out("temp.txt");
	ifstream in("accounts.txt");
	while (getline(in, temp)) {
		if (temp == userID) {
			out << temp << endl;
			getline(in, temp);
			cout << endl << "Enter New Password: ";
			getline(cin, pass);
			out << pass << endl;
			for (int i = 0; i < 2; i++) {
				getline(in, temp);
				out << temp << endl;
			}
		}
		else {
			out << temp << endl;
		}
	}
	in.close();
	out.close();

	remove("accounts.txt");
	rename("temp.txt", "accounts.txt");
	cout << endl << "Password Changed Successfully!" << endl;
	userMenu();
	return;
}

bool searchID(string id) {
	string out;
	bool found = false;

	ifstream in("accounts.txt");
	while (in.eof() == 0) {
		getline(in, out);
		if (id == out) {
			found = true;
		}
	}
	in.close();

	return found;
}

int endMenu() {
	cout << endl << "1. Main Menu \n2. Exit \n\nEnter Choice: ";
	cin >> choice;
	cin.ignore();
	cout << endl;
	return choice;
}
